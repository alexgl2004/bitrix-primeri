<?
	define("NO_KEEP_STATISTIC", true); //Не учитываем статистику
	define("NOT_CHECK_PERMISSIONS", true); //Не учитываем права доступа
	define("NO_CACHE", true);
	
	$begin_time = microtime(true);

	require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");
	
	CModule::IncludeModule('iblock');
	
	require_once($_SERVER["DOCUMENT_ROOT"]."/switch/global_function.php");
	require_once($_SERVER["DOCUMENT_ROOT"]."/mail-params.php");
	require_once($_SERVER["DOCUMENT_ROOT"]."/add-good-function.php");	

	header("Expires: 0");
	header('Content-Type: application/json; charset=utf-8');	

	global $body_post_, $USER, $DB;
	
	require($_SERVER["DOCUMENT_ROOT"]."/switch/authorize_function.php");

	$body_post_ = json_decode(file_get_contents('php://input'), true);
	
	if(!$body_post_){
		$body_post_ = $_REQUEST;
	}
	
//	file_put_contents($_SERVER["DOCUMENT_ROOT"]."/switch/test_folder/add-good.txt",print_r($body_post_,1),FILE_APPEND);

	$json_arr = authorize_user();
	
	if(!$json_arr['error']){
		$user_id = $USER->GetID();
	}else{
		$user_id = '';
	}

	if(CSite::InGroup(array(5))){
		$prodavec = true;
	}else{
		$prodavec = false;
	}
	
	if($user_id && $prodavec && $body_post_){
		
		$_REQUEST_GOODS["product-id"] = $body_post_["id"];

		$_REQUEST_GOODS["GOOD_NAME"] = $body_post_["name"];
		$_REQUEST_GOODS["GOOD_PRICE"] = $body_post_["price"];
		$_REQUEST_GOODS["GOOD_SALE_100"] = $body_post_["sale_100"];
		$_REQUEST_GOODS["GOOD_SALE_1000"] = $body_post_["sale_1000"];

		$_REQUEST_GOODS["GOOD_SKU"]  = $body_post_["sku"];
		$_REQUEST_GOODS["GOOD_WEIGHT"]  = $body_post_["weight"];
		$_REQUEST_GOODS["GOOD_COUNT"]  = $body_post_["count"];
		$_REQUEST_GOODS["GOOD_CAT"]  = $body_post_["section_id"];

		$_REQUEST_GOODS["GOOD_SIZE"] = array();
		$_REQUEST_GOODS["GOOD_COLOR"] = array();

		$body_post_["size"] = json_decode($body_post_["size"],1);
		foreach($body_post_["size"] as $k=>$elem){
			if($body_post_["size"][$k]){
				$_REQUEST_GOODS["GOOD_SIZE"][$k] = $body_post_["size"][$k];
			}
		}

		$body_post_color = json_decode($body_post_["color"],1);

		foreach($body_post_color as $k=>$elem){
			if($body_post_color[$k]){
				$_REQUEST_GOODS["GOOD_COLOR"][$k] = $body_post_color[$k];
			}
		}
		
		end($_REQUEST_GOODS["GOOD_COLOR"]);
		$key_color = key($_REQUEST_GOODS["GOOD_COLOR"]);
		if(!$_REQUEST_GOODS["GOOD_COLOR"][$key_color]){
			array_shift($_REQUEST_GOODS["GOOD_COLOR"]);
		}
	//		echo '<pre>'.print_r($_REQUEST_GOODS,1).'</pre>';die();

		$_REQUEST_GOODS["GOOD_SMALL_DESCRIPTION"] = $body_post_["small_text"];
		$_REQUEST_GOODS["GOOD_DESCRIPTION"] = $body_post_["main_text"];
		
		if(!$_REQUEST_GOODS["GOOD_DESCRIPTION"] && $_REQUEST_GOODS["GOOD_SMALL_DESCRIPTION"]){
			$_REQUEST_GOODS["GOOD_DESCRIPTION"] = $_REQUEST_GOODS["GOOD_SMALL_DESCRIPTION"];
		}
		
		
		$body_post_characts = json_decode($body_post_["characts"],1);
		
		foreach($body_post_characts as $k=>$elem){
			if($body_post_characts[$k]){
				
				if($body_post_characts[$k]["id"]){
					$_REQUEST_GOODS["GOOD_ADD_CHARACT_NAME_ID"][$k] = $body_post_characts[$k]["id"];
					$_REQUEST_GOODS["GOOD_ADD_CHARACT_VALUE"][$k] = $body_post_characts[$k]["val"];
				}else{
					$_REQUEST_GOODS["GOOD_ADD_CHARACT_NAME"][$k] = $body_post_characts[$k]["name"];
					$_REQUEST_GOODS["GOOD_ADD_CHARACT_VALUE"][$k] = $body_post_characts[$k]["val"];
				}
				
			}
		}

		$_REQUEST_GOODS["product-send"] = $body_post_["product-send"];

		if(!is_array($body_post_["files"])){
			$body_post_files = json_decode($body_post_["files"],1);
		}else{
			$body_post_files = $body_post_["files"];
		}

//		$_REQUEST_GOODS['body_post_characts'] = $_SERVER["DOCUMENT_ROOT"];
		
		if($body_post_files){
			foreach($body_post_files as $k=>$elem){
				if($elem['id']){
					$_REQUEST_GOODS["GOOD_PICTURE_ID"][$k] = $elem['id'];
				}else if($elem['name']){
					$image_tmp = explode('base64,',$elem['img_content']);
					$image_tmp[0] = trim($image_tmp[0],';');
					$image_tmp[0] = explode('data:image/',$image_tmp[0]);
					$rashir = ($image_tmp[0][1]!='jpeg'?$image_tmp[0][1]:'jpg');
					$elem['name'] .= '.'.$rashir;
//					$elem['name'] .= (strpos($elem['name'],'.jpg')===false?'.jpg':'');
					$file_name = trim($_SERVER["DOCUMENT_ROOT"]."/upload/tmp/".$elem['name']);

					file_put_contents($file_name,base64_decode($image_tmp[1]));
					$_REQUEST_GOODS["GOOD_PICTURE_TEXT"][$k] = $file_name;
				}
			}
		}
		
//		echo $postavschik.print_r($_REQUEST_GOODS,1);

		$res_ = add_good($user_id, $_REQUEST_GOODS,array(), 0);
		
		$json_arr['post'] = $body_post_;
//		$json_arr['request'] = $_REQUEST_GOODS;
		$json_arr['result'] = $res_;
		
		
	}else{
		
		if(!$prodavec){			
			$json_arr['result'] = array(
				'error'=>2,
				'message'=>'Вы не являетесь продавцом'//.$user_id.' && '.$prodavec.' && '.print_r($body_post_,1)
			);
		}
		
	}

	echo json_encode($json_arr);

	$end_time = microtime(true);
	$all_time_sek = ($end_time - $begin_time);
	file_put_contents($_SERVER['DOCUMENT_ROOT'].'/switch/test_times/add-good.txt',"----Время выполнения - ".$all_time_sek." c.----, date(".date('Y-m-d H:i:s').")-----".print_r($body_post_,1).'^^^'.print_r($json_arr,1)."\n",FILE_APPEND);

?>