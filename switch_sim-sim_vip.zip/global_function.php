<?

	function save_online($user_id=0){
		
		global $USER;
		
		if(!$user_id){
			$user_id = $USER->GetID();
		}
		
		if($user_id){
			file_put_contents($_SERVER['DOCUMENT_ROOT'].'/chat/check_online/time_'.$user_id.'.txt',date('Y-m-d H:i:s'));		
		}
		
	}
	
	function get_online($user_id){
		if($user_id){
			$date_than = file_get_contents($_SERVER['DOCUMENT_ROOT'].'/chat/check_online/time_'.$user_id.'.txt');
			$date_now = date('Y-m-d H:i:s');
			if($date_than){
				
				$datetime1 = new DateTime($date_than);
				$datetime2 = new DateTime($date_now);
				$interval = $datetime1->diff($datetime2);
//				echo '<pre>'.print_r($interval,1).'</pre>';
				
				return ($interval->s<=60?true:false);
				
			}else{
				return false;
			}

		}else{
			return false;
		}		
		
	}

?>