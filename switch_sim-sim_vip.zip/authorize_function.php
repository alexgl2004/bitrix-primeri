<?

	function authorize_user(){

		global $DB, $USER;
		
//		CModule::IncludeModule('user');
		$body_post_ = json_decode(file_get_contents('php://input'), true);
		if(!$body_post_){
			$body_post_ = $_REQUEST;
		}
		
//		$body_post_['password'] = str_replace('*','#',$body_post_['password']);
		
//		file_put_contents($_SERVER['DOCUMENT_ROOT'].'/switch/test_times/test_file_authorize_user.txt',print_r($body_post_,1),FILE_APPEND);
	
		$user_login = $body_post_['login'];
		$user_pass = $body_post_['password'];
		$user_os_id = $body_post_['os_id'];
		
		$user_hash = $body_post_['hash'];
		
		$arr_params = array();
		
		if (!is_object($USER)){
			
			$USER = new CUser;
			$authorized = false;
			
		}else{
			
			if($USER->GetID()){
				$authorized = true;
			}else{
				$authorized = false;
			}

		}
		
		if($authorized===false){
		
			$get_hash = $body_post_['get_hash'];
			
			if($user_login && $user_hash){
				
				$authorized = $USER->LoginByHash($user_login,$user_hash);
				
			}else if($user_login && $user_pass){
				
				$authorized = $USER->Login($user_login,$user_pass);
				
			}else{
				
				$error_login = 3;//Не все поля заполнены
				$authorized = false;
				
			}
		
		}		
		
		if($authorized === true){

			$arr_params['id'] = $USER->GetID();
			$arr_params['login'] = $USER->GetLogin();
			$arr_params['group'] = (in_array("5",$USER->GetUserGroupArray())?5:6);
			$arr_params['all_groups'] = $USER->GetUserGroupArray();
			
		
			if($user_os_id){
				
				$fields = Array( 
					"UF_OS_ID" => $user_os_id, 
				); 
				$USER->Update($arr_params['id'], $fields);
				$_SESSION['os_id'] = $user_os_id;
			}

			if(!$arr_params['id']){
				
				unset ($arr_params['id'],$arr_params['login']);
				$arr_params['error'] = 2;
				$arr_params['auth'] = 0;
				
			}else{
				
				if($get_hash){
					$arr_params['hash'] = $USER->GetParam("PASSWORD_HASH");
				}
				
				$arr_params['error'] = 0;
				$arr_params['auth'] = 1;
				

				
			}
			
		}else{
			
			$arr_params['error'] = -1;
			$arr_params['auth'] = 0;
			
		}
		
//		$arr_params = array();

//		file_put_contents($_SERVER['DOCUMENT_ROOT'].'/switch/test_file_authorize_user.txt',print_r($arr_params,1),FILE_APPEND);
		
		save_online();

		return $arr_params;
		
	}

/**********************************************************************************************************/	

	function register_user(){

		global $USER;
		
		$body_post_ = json_decode(file_get_contents('php://input'), true);
		
//		file_put_contents($_SERVER['DOCUMENT_ROOT'].'/switch/test_file_register_user.txt',print_r($body_post_,1),FILE_APPEND);
	
		$user_type = $body_post_['type'];// - тип пользователя
		
		if(!trim($body_post_['login'])){
			$body_post_['login'] = $body_post_['email'];
		}
	
		$user_login = $body_post_['login'];
		$user_pass = $body_post_['password'];
		
		$user_email = $body_post_['email'];
		$user_name = $body_post_['name'];
		$user_last_name = $body_post_['last_name'];
		
		$user_company_name = $body_post_['company_name'];
		$user_address = $body_post_['address'];
		
		$arr_params = array();
		
		$arResult = $USER->Register(
			$user_login, 
			$user_name, 
			$user_last_name, 
			$user_pass, 
			$user_pass, 
			$user_email,
			's1'
		);
		
/*
		$el->SetPropertyValuesEx($good_fields_['ID'],16, array('CITY'=>$arFields['WORK_CITY']));
*/	

		$arr_params['error'] = ($arResult['TYPE']=='ERROR'?6:0);
		$arr_params['message'] = str_replace('<br>','',strip_tags($arResult['MESSAGE']));
		
		$body_post_['gid'] = ($body_post_['gid']?$body_post_['gid']:$body_post_['type']);
		$body_post_['gid'] = ($body_post_['gid']?$body_post_['gid']:5);
		
		if($USER->GetID()){
			$arr_params['id'] = $USER->GetID();
			$USER->SetUserGroup($arr_params['id'], array($body_post_['gid']));
			$arr_params['gid'] = $body_post_['gid'];
			$arr_params['login'] = $USER->GetLogin();
			$arr_params['hash'] = $USER->GetParam("PASSWORD_HASH");
			$arr_params['tech'] = $arResult;
		}
		
//		file_put_contents($_SERVER['DOCUMENT_ROOT'].'/switch/test_file_register_user.txt',print_r($arr_params,1),FILE_APPEND);
		
		return $arr_params;
		
	}

/**********************************************************************************************************/		

	function logout_user(){

		global $USER;
		$body_post_ = json_decode(file_get_contents('php://input'), true);
		if(!$body_post_){
			$body_post_ = $_REQUEST;
		}
		
		if($body_post_['logout']){
			$USER->Logout();
		}
	}
	
	function viewNotifications(){ 
	
		$app_id = "dea6806f-0a50-40ac-8c3f-117f2cd7feae";
	
		$curl = curl_init();

		curl_setopt_array($curl, array(
		  CURLOPT_URL => "https://onesignal.com/api/v1/notifications?app_id=".$app_id."&limit=50&offset=0",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "GET",
		  CURLOPT_HTTPHEADER => array(
			"authorization: Basic OWM3MTk2NGQtZGM3ZC00NjljLThiNWYtMjcxMzY0NTExYjY3",
		  ),
		));

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		return $response;
	}

	function getDevices(){ 
	
		$app_id = "dea6806f-0a50-40ac-8c3f-117f2cd7feae";
		$ch = curl_init(); 
		curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/players?app_id=" . $app_id); 
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json', 
													 'Authorization: Basic OWM3MTk2NGQtZGM3ZC00NjljLThiNWYtMjcxMzY0NTExYjY3')); 
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE); 
		curl_setopt($ch, CURLOPT_HEADER, FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		$response = curl_exec($ch); 
		curl_close($ch); 
		
		return $response;
		
	}

/*****************************************************Скорее всего удалить ее нужно будет**************************************************/
    function sendMessage_os_id($os_id, $to_ged_push_user_id, $sMessage='',$is_files_product=0,$id_chat_message=''){
		
		$app_id = "dea6806f-0a50-40ac-8c3f-117f2cd7feae";
		
		switch($is_files_product){
			case 1:
				$content = array(
					"en" => (trim($sMessage)?$sMessage:'You have a new message-file'),
					"ru" => (trim($sMessage)?$sMessage:'Получено сообщение-файл')
				);
			break;
			case 2:
				$content = array(
					"en" => (trim($sMessage)?$sMessage:'You have a new order in messages'),
					"ru" => (trim($sMessage)?$sMessage:'Получен заказ на товар')
				);
			break;
			default:
				$content = array(
					"en" => (trim($sMessage)?$sMessage:'You have a new message'),
					"ru" => (trim($sMessage)?$sMessage:'Вам пришло сообщение')
				);
			break;
		}
        
        $fields = array(
            'app_id' => $app_id,
            'include_player_ids' => array($os_id),
//			'include_external_user_ids' => array($os_id),
            'data' => array("mobile" => "yes"),
            'contents' => $content
        );

		if($id_chat_message){
			$fields['data']['chat_id'] = $id_chat_message;
		}		
        
        $fields = json_encode($fields);
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
        curl_setopt($ch, CURLOPT_HTTPHEADER, 
			array(
				'Content-Type: application/json; charset=utf-8',
//				'Authorization: Basic OWM3MTk2NGQtZGM3ZC00NjljLThiNWYtMjcxMzY0NTExYjY3'
			)
		);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);

        $response = curl_exec($ch);
        curl_close($ch);
		
		$response_arr = json_decode($response);
		
		file_put_contents(
			$_SERVER['DOCUMENT_ROOT'].'/switch/test_times/send_push_to_user_id.txt',
				date('Y-m-d H:i:S').': '."\n".
				$to_ged_push_user_id.'||'.$os_id."\n".
				$sMessage."\n".
				print_r($response_arr,1)."\n"
//				.print_r(json_decode(viewNotifications(),1),1)."\n"
//				.print_r(json_decode(getDevices(),1),1)."\n"
			,FILE_APPEND
		);
        
        return $response;
		
    }	

?>