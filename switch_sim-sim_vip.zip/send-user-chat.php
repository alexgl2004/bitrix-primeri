<?
	define("NO_KEEP_STATISTIC", true); //Не учитываем статистику
	define("NOT_CHECK_PERMISSIONS", true); //Не учитываем права доступа
	define("NO_CACHE", true);
	
	require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");
	include_once($_SERVER["DOCUMENT_ROOT"].'/personal/profile/chat/inc/ajx_chat.inc.php');
	include_once($_SERVER["DOCUMENT_ROOT"].'/switch/make_thumbs.php');
	require($_SERVER["DOCUMENT_ROOT"]."/switch/global_function.php");

	header("Expires: 0");
	header('Accept: application/json');
	header('Content-Type: application/json; charset=utf-8');

	error_reporting(0);

	global $body_post_;
	
	$body_post_ = json_decode(file_get_contents('php://input'), true);
	
//	file_put_contents($_SERVER['DOCUMENT_ROOT'].'/switch/test_file_chat.txt','||'.file_get_contents('php://input').'||',FILE_APPEND);

	if(!$body_post_){
		$body_post_ = $_REQUEST;
	}
	
//	file_put_contents($_SERVER['DOCUMENT_ROOT'].'/switch/test_file_chat.txt',print_r($body_post_,1),FILE_APPEND);
	
	$arrFilter_top = array();

	global $USER, $arrFilter_top, $DB;
	
	require($_SERVER["DOCUMENT_ROOT"]."/switch/authorize_function.php");
	
	CModule::IncludeModule('iblock');

	$el = new CIBlockElement();
	
	$json_arr = authorize_user();
	
	if(!$json_arr['error']){
		$user_id = $USER->GetID();
//		$json_arr['auth'] = true;
	}else{
		$user_id = '';
//		$json_arr['auth'] = false;
	}

	if( $body_post_['client_id'] ){
		$prodavec = true;
	}else{
		$prodavec = false;
	}

	$product_id = (int)$body_post_['product_id'];
	$size_ = (float)$body_post_['size'];
	$color_ = strip_tags(addslashes($body_post_['color']));
	
	$postavschik_id = (int)$body_post_['postavschik_id'];
	$client_id = (int)$body_post_['client_id'];
	
//	$postavschik_id = $user_id;
//	$client_id = ($body_post_['postavschik_id']?(int)$body_post_['postavschik_id']:(int)$body_post_['client_id']);

	$deleted = '';
	
	$price_ = explode(' ',$body_post_['price']);
	$price_ = $price_[0];

	if($body_post_['buy']=='Y' && $product_id){
		
		$res = CIBlockElement::GetByID($product_id);
		if($ar_res = $res->GetNext()){
//					echo '<pre>'.print_r($ar_res,1).'</pre>';
			
			$name_ = $ar_res['NAME'];
			$text_ = $ar_res['PREVIEW_TEXT'];
			$picture_ = CFile::GetPath($ar_res['PREVIEW_PICTURE']);
			$url_ = $ar_res['DETAIL_PAGE_URL'];
			
			$message_ = '<a target="_blank" href="'.$url_.'"><img src="'.$picture_.'" style="width:100%;height:auto;max-width:120px;border-radius:5px;" alt="" /></a>
				<b>Покупка товара</b>: '.'<br>'.
				'Название: '.$name_.'<br>'.
				($color_?'цвет: <span style="background-color:#'.$color_.';width:20px;height:20px;display:inline-block;border-radius:5px;"></span><br>':'').
				($size_?'размер: '.$size_.'<br>':'').
				'Цена: '.number_format($price_,2,'.','').' руб.'.'<br>'.
				'<a target="_blank" href="'.$url_.'">Ссылка на товар</a><br>'.
			'';

//					echo $message_;die();					
			
//					die();
			$GLOBALS['AjaxChat']->add_product_to_message($postavschik_id, $message_);	
		}else{
			$json_arr['no_send'] = 'no product';
		}
		
	}else{
		
		if($body_post_['test']==1){
			$user_id = 338;
			$body_post_['postavschik_id'] = '1';
//			$body_post_['client_id'] = '338';
			$body_post_['type'] = 'file';
			$body_post_['files'] = array(
				array(
					'base64'=>'sadfsd#fsdfsdfsdfsdfrrkrkrkewklk#$',
					'type_file'=>'sound',
					'ext'=>'mp3'
				)
/*				
				array(
					'base64'=>'adfgdhgdfghdfhjytjtujujtujju',
					'type_file'=>'sound',
					'ext'=>'mp3'
				)
*/				
			);
		}
		
		if($body_post_['type']=='delete_chat' && $user_id){
			
			$deleted = $GLOBALS['AjaxChat']->makeDelChat($body_post_['client_id']);
			
		}else{
		
			if($body_post_['type']=='file' && $user_id){

				$file_dir = $_SERVER['DOCUMENT_ROOT'].'/upload/chat_files/files_'.$user_id.'/';
				if(!file_exists($file_dir)){
					mkdir($file_dir);
				}
				
				$k_add = 1;
				$file_names = array();
				
				foreach($body_post_['files'] as $elem){
					$k_add += 1;
					$content_file = base64_decode($elem['base64']);
					$file_type = $elem['type_file'];
					$file_ext = $elem['ext'];
					$file_name_ = substr(md5($file_type.'-'.date('Y-m-dTH-i-s')),1,12).'-'.date('Y-m-dTH-i-s').'-'.$k_add.'.'.$file_ext;
					file_put_contents($file_dir.$file_name_,$content_file);
					
					$files_[$k_add]['name'] = $file_name_;
					$files_[$k_add]['ext'] = $file_ext;
					$files_[$k_add]['type'] = $file_type;
					
				}

				make_mini_images($user_id);

			}
			
			$message_ = $body_post_['message'];
			$data_temp = $GLOBALS['AjaxChat']->acceptMessages($message_, $user_id, $files_, $file_dir);
			
			if($files_){

				$files_ids = $data_temp['file_ids'];
				$files_links = $data_temp['file_links'];
				$json_arr['files'] = $files_links;
				
			}
			
		}
		
	}
	
	if($body_post_['type']=='delete_chat'){
		
		if($deleted){
			$json_arr['deleted'] = 1;
		}else{
			$json_arr['deleted'] = 0;
		}
		
	}else{
	
		if($message_ || $files_){
			$json_arr['sended'] = 1;
		}else{
			$json_arr['sended'] = 0;
			if(!$json_arr['no_send']){
				$json_arr['no_send'] = 'no message';
			}
		}
	}

	$GLOBALS['AjaxChat']->check_status(true);

//	file_put_contents($_SERVER['DOCUMENT_ROOT'].'/switch/test_file_chat.txt',"\n".json_encode($json_arr)."\n",FILE_APPEND);
	
	echo json_encode($json_arr);

?>