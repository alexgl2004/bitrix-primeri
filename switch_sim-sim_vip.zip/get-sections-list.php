<?

	define("NO_KEEP_STATISTIC", true); //Не учитываем статистику
	define("NOT_CHECK_PERMISSIONS", true); //Не учитываем права доступа
	require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");
	require($_SERVER["DOCUMENT_ROOT"]."/switch/global_function.php");
	
	$begin_time = microtime(true);

	header("Expires: 0");
	header('Content-Type: application/json; charset=utf-8');

	$json_arr = array();
	
	$file_dir = '/home/bitrix/www/bitrix/cache/switch/';
	
	if(!file_exists($file_dir)){
		mkdir($file_dir);
	}
	
	$file_name = $file_dir.'cache_section_list_'.date('Y_m_d_H').'.txt';
	
	if(!file_exists($file_name)){	
	
		$body_post_ = json_decode(file_get_contents('php://input'), true);

		global $USER;
		
		CModule::IncludeModule('iblock');
		
		save_online();

		$IBLOCK_ID_GOODS = 16;
		
		$arFilter = Array('IBLOCK_ID'=>$IBLOCK_ID_GOODS, 'GLOBAL_ACTIVE'=>'Y');
		$arSeletc = 
		$db_list = CIBlockSection::GetList(Array($by=>$order), $arFilter, true, array('ID','CODE','NAME','DEPTH_LEVEL','PICTURE','UF_COLOR','UF_IMAGE_MENU'));

		$two_cats = array();
		$two_cats['level1'] = array();
		
		while($ar_result = $db_list->GetNext()){
			
	//		echo '<pre>'.print_r($ar_result,1).'</pre>';
			
			switch($ar_result['DEPTH_LEVEL']){
				case '1':
					$two_cats['level1'][$ar_result['ID']]['ID'] = $ar_result['ID'];
					$two_cats['level1'][$ar_result['ID']]['NAME'] = $ar_result['NAME'];
					$two_cats['level1'][$ar_result['ID']]['CODE'] = $ar_result['CODE'];
					$two_cats['level1'][$ar_result['ID']]['PICTURE'] = $ar_result['PICTURE'];
					$two_cats['level1'][$ar_result['ID']]['DETAIL_PICTURE'] = $ar_result['DETAIL_PICTURE'];
					$two_cats['level1'][$ar_result['ID']]['UF_COLOR'] = $ar_result['UF_COLOR'];
					$two_cats['level1'][$ar_result['ID']]['UF_IMAGE_MENU'] = $ar_result['UF_IMAGE_MENU'];
					$two_cats['level1'][$ar_result['ID']]['ELEMENT_CNT'] = $ar_result['ELEMENT_CNT'];
				break;
				case '2':
					$two_cats['level1'][$ar_result['IBLOCK_SECTION_ID']]['CHILDS'][$ar_result['ID']]['ID'] = $ar_result['ID'];
					$two_cats['level1'][$ar_result['IBLOCK_SECTION_ID']]['CHILDS'][$ar_result['ID']]['NAME'] = $ar_result['NAME'];
					$two_cats['level1'][$ar_result['IBLOCK_SECTION_ID']]['CHILDS'][$ar_result['ID']]['CODE'] = $ar_result['CODE'];
					$two_cats['level1'][$ar_result['IBLOCK_SECTION_ID']]['CHILDS'][$ar_result['ID']]['PICTURE'] = $ar_result['PICTURE'];
					$two_cats['level1'][$ar_result['IBLOCK_SECTION_ID']]['CHILDS'][$ar_result['ID']]['DETAIL_PICTURE'] = $ar_result['DETAIL_PICTURE'];
					$two_cats['level1'][$ar_result['IBLOCK_SECTION_ID']]['CHILDS'][$ar_result['ID']]['UF_COLOR'] = $ar_result['UF_COLOR'];
					$two_cats['level1'][$ar_result['IBLOCK_SECTION_ID']]['CHILDS'][$ar_result['ID']]['UF_IMAGE_MENU'] = $ar_result['UF_IMAGE_MENU'];
					$two_cats['level1'][$ar_result['IBLOCK_SECTION_ID']]['CHILDS'][$ar_result['ID']]['ELEMENT_CNT'] = $ar_result['ELEMENT_CNT'];
				break;
			}
		}
		
	//	echo 'Список ID категорий для поля SECTION_ID в файле import.csv'."\n"."\n";
		
		$json_arr = array();
		
		foreach($two_cats['level1'] as $k=>$elem){
			$json_arr[$elem['ID']]['id'] = $elem['ID'];
			$json_arr[$elem['ID']]['name'] = $elem['NAME'];
			$json_arr[$elem['ID']]['code'] = $elem['CODE'];
			if($elem['PICTURE']){
				$json_arr[$elem['ID']]['imageCatalog'] = 'https://sim-sim.vip'.Cfile::getPath($elem['PICTURE']);
			}
			if($elem['DETAIL_PICTURE']){
				$json_arr[$elem['ID']]['otherImg'] = 'https://sim-sim.vip'.Cfile::getPath($elem['DETAIL_PICTURE']);
			}
			if($elem['UF_IMAGE_MENU']){
				$json_arr[$elem['ID']]['imageMenu'] = 'https://sim-sim.vip'.Cfile::getPath($elem['UF_IMAGE_MENU']);
			}
			$json_arr[$elem['ID']]['color'] = $elem['UF_COLOR'];
			$json_arr[$elem['ID']]['countElems'] = $elem['ELEMENT_CNT'];
			
			$json_arr[$elem['ID']]['parent'] = 0;
			$json_arr[$elem['ID']]['level'] = 1;
			if($elem['CHILDS']){
				foreach($elem['CHILDS'] as $k_in=>$elem_in){
					$json_arr[$elem_in['ID']]['id'] = $elem_in['ID'];
					$json_arr[$elem_in['ID']]['name'] = $elem_in['NAME'];
					$json_arr[$elem_in['ID']]['code'] = $elem_in['CODE'];
					if($elem_in['PICTURE']){
						$json_arr[$elem_in['ID']]['imageCatalog'] = 'https://sim-sim.vip'.Cfile::getPath($elem_in['PICTURE']);
					}
					if($elem_in['DETAIL_PICTURE']){
						$json_arr[$elem_in['ID']]['otherImg'] = 'https://sim-sim.vip'.Cfile::getPath($elem_in['DETAIL_PICTURE']);
					}
					if($elem_in['UF_IMAGE_MENU']){
						$json_arr[$elem_in['ID']]['imageMenu'] = 'https://sim-sim.vip'.Cfile::getPath($elem_in['UF_IMAGE_MENU']);
					}
					$json_arr[$elem_in['ID']]['color'] = $elem_in['UF_COLOR'];
					$json_arr[$elem_in['ID']]['countElems'] = $elem_in['ELEMENT_CNT'];
					$json_arr[$elem_in['ID']]['parent'] = $elem['ID'];
					$json_arr[$elem_in['ID']]['level'] = 2;
				}
			}
		}
		
//	file_put_contents($_SERVER['DOCUMENT_ROOT'].'/switch/test_file_user_prods.txt',"\n".json_encode($json_arr)."\n");
//		echo json_encode($json_arr, JSON_HEX_QUOT);
		file_put_contents($file_name,json_encode($json_arr));
		echo json_encode($json_arr, JSON_HEX_QUOT);
		
	}else{
		
		$json_arr = file_get_contents($file_name);
		echo $json_arr;
		
	}

	$end_time = microtime(true);
	$all_time_sek = ($end_time - $begin_time);
	file_put_contents($_SERVER['DOCUMENT_ROOT'].'/switch/test_times/get-sections-list.txt',"----Время выполнения - ".$all_time_sek." c.----, date(".date('Y-m-d H:i:s').")-----".print_r($body_post_,1)."\n",FILE_APPEND);

?>