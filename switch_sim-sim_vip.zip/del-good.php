<?

	define("NO_KEEP_STATISTIC", true); //Не учитываем статистику
	define("NOT_CHECK_PERMISSIONS", true); //Не учитываем права доступа
	require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");

	header("Expires: 0");
	header('Content-Type: application/json; charset=utf-8');	
	
	CModule::IncludeModule('iblock');

	global $USER;

	require_once($_SERVER["DOCUMENT_ROOT"]."/switch/global_function.php");
	require_once($_SERVER["DOCUMENT_ROOT"]."/switch/authorize_function.php");

	$body_post_ = json_decode(file_get_contents('php://input'), true);
	
	if(!$body_post_){
		$body_post_ = $_REQUEST;
	}

	$el_id_Delete = $body_post_['id'];	
	
//	file_put_contents($_SERVER["DOCUMENT_ROOT"]."/switch/test_folder/add-good.txt",print_r($body_post_,1),FILE_APPEND);

	$json_arr = authorize_user();
	
	if(!$json_arr['error']){
		$user_id = $USER->GetID();
	}else{
		$user_id = '';
	}
	
	if(!$el_id_Delete){
		
		$json_arr['result'] = array(
			'error'=>29,
			'message'=>'Товар не указан'
		);
		
	}else{
	
		if($user_id){

			$id_iblok_catalog= 16; //это число-id инфоблока 
			$db_props = CIBlockElement::GetProperty($id_iblok_catalog, $el_id_Delete, array("sort" => "asc"), Array("CODE"=>"POSTAVSCHIK"));
			
			if($ar_props = $db_props->Fetch()){
				$USER_ID_TOVAR = IntVal($ar_props["VALUE"]);
			}else{
				$USER_ID_TOVAR = false;
			}
			
			if($user_id == $USER_ID_TOVAR){
			
				$el = new CIBlockElement();
				$el_ID = $el->Delete($el_id_Delete);
				
				$json_arr['result'] = array(
					'success'=>1,
					'message'=>'Успешно удалено'
				);
					
			}else{
				$json_arr['result'] = array(
					'error'=>28,
					'message'=>'Товар не пренадлежит текущему продавцу'
				);
			}
			
		}else{

			$json_arr['result'] = array(
				'error'=>2,
				'message'=>'Вы не являетесь продавцом'//.$user_id.' && '.$prodavec.' && '.print_r($body_post_,1)
			);
			
		}
		
	}
	
	echo json_encode($json_arr);
//	echo 'aaa';
?>