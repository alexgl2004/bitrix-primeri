<?
	define("NO_KEEP_STATISTIC", true); //Не учитываем статистику
	define("NOT_CHECK_PERMISSIONS", true); //Не учитываем права доступа
//	define("NO_CACHE", true);
	
	$begin_time = microtime(true);

	require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");
	require_once($_SERVER["DOCUMENT_ROOT"]."/switch/global_function.php");
	require_once($_SERVER["DOCUMENT_ROOT"]."/add-good-function.php");	

	header("Expires: 0");
	header('Content-Type: application/json; charset=utf-8');	

	global $body_post_, $USER, $DB;
	
	require($_SERVER["DOCUMENT_ROOT"]."/switch/authorize_function.php");

	$json_arr = authorize_user();
	
	if(!$json_arr['error']){
		$user_id = $USER->GetID();
	}else{
		$user_id = '';
	}

	if(CSite::InGroup( array(5))){
		$prodavec = true;
	}else{
		$prodavec = false;
	}

	$body_post_ = json_decode(file_get_contents('php://input'), true);
	
	if(!$body_post_){
		$body_post_ = $_REQUEST;
	}
	
	if($user_id && $prodavec && $body_post_){
		
//		echo $tov_id.'ss';
		
		$tov_id = $body_post_["id"];

			if($tov_id){
			
				CModule::IncludeModule('iblock');
				
				$res = CIBlockElement::GetByID($tov_id);
				$res_property =  CIBlockElement::GetProperty(16,$tov_id,array("sort" => "asc"),array(
						'STARTSHOP_QUANTITY',
						'STARTSHOP_QUANTITY_RATIO',
						'POSTAVSCHIK',
						'STARTSHOP_PRICE_1',
						'STARTSHOP_PRICE_2',
						'STARTSHOP_PRICE_3',
						'STARTSHOP_CURRENCY_1',
						'SYSTEM_ARTICLE',
						
						'WEIGHT',
						'SIZE',
						'COLOR',
						'CHARACT_IN_ONE',
						
						'DOP_FIELD_BRAND',
						'SEASON',
						'DOP_FIELD_STELKA',
						'DOP_FIELD_MATERIAL',
						'DOP_FIELD_VN_MATERIAL',
						'DOP_KOL',
						'DOP_VID_SPORT',
						'DOP_COUNTRY',
						
					)
				);

				$edit_tovar = array();
				
				if($ar_res = $res->GetNext()){

					$edit_tovar['ID'] = $tov_id;
					$edit_tovar['NAME'] = $ar_res['NAME'];
					$edit_tovar['CATEGORY'] = $ar_res['IBLOCK_SECTION_ID'];
//					$edit_tovar['SYSTEM_IMAGES'][] = CFile::GetPath($ar_res['PREVIEW_PICTURE']);
					$edit_tovar['SYSTEM_IMAGES'][] = CFile::GetPath($ar_res['PREVIEW_PICTURE']);
					$edit_tovar['IMAGES'][] = array('ID'=>$ar_res['PREVIEW_PICTURE'],'path'=>CFile::GetPath($ar_res['PREVIEW_PICTURE']));
					$edit_tovar['small_text'] = $ar_res['PREVIEW_TEXT'];
					$edit_tovar['main_text'] = $ar_res['DETAIL_TEXT'];

					$res_prop = CIBlockElement::GetProperty(16,$tov_id,array("sort" => "asc"),array("CODE" => "SYSTEM_IMAGES"));
					while ($ob = $res_prop->GetNext()){
						if($ob['VALUE']){
							$edit_tovar['SYSTEM_IMAGES'][] = CFile::GetPath($ob['VALUE']);
							$edit_tovar['IMAGES'][] = array('ID'=>$ob['VALUE'],'path'=>CFile::GetPath($ob['VALUE']));
						}
					}

					$res_prop = CIBlockElement::GetProperty(16,$tov_id,array("sort" => "asc"),array("CODE" => "COLOR"));
					while ($ob = $res_prop->GetNext()){
						if($ob['VALUE']){
							$edit_tovar['COLOR'][] = $ob['VALUE'];
						}
					}
					
					$res_prop = CIBlockElement::GetProperty(16,$tov_id,array("sort" => "asc"),array("CODE" => "SIZE"));
					while ($ob = $res_prop->GetNext()){
						if($ob['VALUE']){
							$edit_tovar['SIZE'][] = $ob['VALUE'];
						}
					}
					
					$res_prop = CIBlockElement::GetProperty(16,$tov_id,array("sort" => "asc"),array("CODE" => "CHARACT_IN_ONE"));
					while ($ob = $res_prop->GetNext()){
						if($ob['VALUE']){
							$edit_tovar['CHARACT_IN_ONE'][] = $ob['VALUE'];
						}
					}
					
					while ($ob = $res_property->GetNext()){
		//				echo '<pre>'.print_r($ob,1).'</pre>';
						
						switch($ob['CODE']){
							case 'STARTSHOP_QUANTITY':
								$edit_tovar['STARTSHOP_QUANTITY'] = $ob['VALUE'];					
							break;
							case 'STARTSHOP_QUANTITY_RATIO':
								$edit_tovar['STARTSHOP_QUANTITY_RATIO'] = $ob['VALUE'];
							break;
							case 'POSTAVSCHIK':
								$edit_tovar['POSTAVSCHIK'] = $ob['VALUE'];					
							break;
							case 'STARTSHOP_PRICE_1':
								$edit_tovar['STARTSHOP_PRICE_1'] = $ob['VALUE'];					
							break;
							case 'STARTSHOP_PRICE_2':
								$edit_tovar['STARTSHOP_PRICE_2'] = $ob['VALUE'];					
							break;
							case 'STARTSHOP_PRICE_3':
								$edit_tovar['STARTSHOP_PRICE_3'] = $ob['VALUE'];					
							break;
							case 'STARTSHOP_CURRENCY_1':
								$edit_tovar['STARTSHOP_CURRENCY_1'] = $ob['VALUE'];
							break;
							
							case 'SYSTEM_ARTICLE':
								$edit_tovar['SYSTEM_ARTICLE'] = $ob['VALUE'];
							break;
							case 'WEIGHT':
								$edit_tovar['WEIGHT'] = $ob['VALUE'];
							break;
						}	
						
						if(stripos($ob['CODE'],'DOP_')!==false){
							if($ob['VALUE']){
								$edit_tovar['ANOTHER_PROPERTIES'][] = $ob['NAME'].'||'.$ob['VALUE'].'||'.$ob['CODE'];
							}
						}

					}
					
					if($user_id==$edit_tovar['POSTAVSCHIK']){
						
						$json_arr['result'] =$edit_tovar;
						
					}else{
						
						$json_arr['result'] = '';
						$json_arr['error'] = 12;
						$json_arr['message'] = 'Неверный поставщик';
						
					}

				}
			
			}else{
				
				$json_arr['error'] = 2;
				$json_arr['message'] = 'Вы не являетесь продавцом';
				
			}
		
	}else{
		
		if(!$prodavec){			
			$json_arr['result'] = array(
				'error'=>2,
				'message'=>'Вы не являетесь продавцом'
			);
		}
		
	}

	echo json_encode($json_arr);

	$end_time = microtime(true);
	$all_time_sek = ($end_time - $begin_time);
	file_put_contents($_SERVER['DOCUMENT_ROOT'].'/switch/test_times/get-good.txt',"----Время выполнения - ".$all_time_sek." c.----, date(".date('Y-m-d H:i:s').")-----".print_r($body_post_,1)."\n",FILE_APPEND);

?>