<?

	$begin_time = microtime(true);
//	header("Expires: 0");
	header('Content-Type: application/json; charset=utf-8');
	
	$json_arr = array();
	
	$file_dir = '/home/bitrix/www/bitrix/cache/switch/';
	
	if(!file_exists($file_dir)){
		mkdir($file_dir);
	}
	
	$file_name = $file_dir.'cache_main_'.date('H').'.txt';
	
	if(!file_exists($file_name)){
		
		array_map('unlink', glob($file_dir.'cache_main_*.txt'));
	
		$main_page = file_get_contents('https://sim-sim.vip/');
		
		$main_page_prods = json_decode(file_get_contents('https://sim-sim.vip/switch/get-users-prods.php?prod=1&best=1&only_three=1'),1);
		$main_page_products = json_decode(file_get_contents('https://sim-sim.vip/switch/get-products.php?new=1&only_three=1'),1);
		
		$preg_bool = preg_match_all('/class\=\"news-list-slider\"(.*?)Категории товаров(.*?)widget-block-item-address\"\>(.*?)widget-block-item-title\"\>(.*?)\<\/div\>(.*?)widget-block-item-value\"\>(.*?)\<\/div\>(.*?)widget-block-item-value\"\>(.*?)\<\/div\>(.*?)widget-block-item-phone\"\>(.*?)widget-block-item-title\"\>(.*?)\<\/div\>(.*?)intec-cl-text-hover\"\>(.*?)\<\/a\>(.*?)\<ul class\=\"social(.*?)intec-ui-mod-simple\"(.*?)\<\/ul\>/is',$main_page,$match);
		
		$match_new = array();
		
		foreach($match as $k=>$elem){
			$match_new[$k] = trim(str_replace(array("\t","\r","\n"),'',$match[$k][0]));
		}
		
		$json_arr['city'] = $match_new[6];
		$json_arr['address'] = $match_new[8];
		$json_arr['phone'] = $match_new[13];
		
		$json_arr['slider'] = array();
		$preg_bool = preg_match_all('/class\=\"slider-item\"(.*?)data-dot\=\"(.*?)style\=\"background-image\:(.*?)url\((.*?)\)\;/is',$match[1][0],$match2);//(.*?)\>slider-title\"(.*?)\>(.*?)\<\/div\>(.*?)slider-description\"(.*?)\>(.*?)\<\/div\>
		
	//	echo '<pre>'.print_r($match[1][0],1).'</pre>';
	//	echo '<pre>'.print_r($match2,1).'</pre>';
		
		foreach($match2[4] as $elem){
			$json_arr['slider'][] = trim($elem,'&#039;');
		}

		$json_arr['social'] = array();
		$preg_bool = preg_match_all('/\<li\>(.*?)href\=\"(.*?)\"\>(.*?)puple fab fa\-(.*?)\"\>(.*?)\<\/li\>/is',$match[16][0],$match3);
		
		
		foreach($match3[4] as $k=>$elem){
			if($match3[2][$k] && $match3[2][$k]!='/'){
				switch($elem){
					case 'facebook-square':
						$json_arr['social']['facebook'] = $match3[2][$k];
					break;
					case 'youtube':
						$json_arr['social']['youtube'] = $match3[2][$k];
					break;
					case 'vk':
						$json_arr['social']['vk'] = $match3[2][$k];
					break;
					case 'instagram':
						$json_arr['social']['instagram'] = $match3[2][$k];
					break;
					default:
						$json_arr['social'][$elem] = $match3[2][$k];
					break;			
				}
			}
		}

		$json_arr['best_postaschik'] = $main_page_prods;
		$json_arr['new_products'] = $main_page_products['products'];
		
		file_put_contents($file_name,json_encode($json_arr));
		echo json_encode($json_arr);
		
	}else{
		
		$json_arr = file_get_contents($file_name);
		echo $json_arr;
		
	}
	
	$end_time = microtime(true);
	$all_time_sek = ($end_time - $begin_time);
	file_put_contents($_SERVER['DOCUMENT_ROOT'].'/switch/test_times/main_info.txt',"----Время выполнения - ".$all_time_sek." c.----, date(".date('Y-m-d H:i:s').")-----".print_r($body_post_,1)."\n",FILE_APPEND);

?>