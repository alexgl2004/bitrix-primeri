	<?
	define("NO_KEEP_STATISTIC", true); //Не учитываем статистику
	define("NOT_CHECK_PERMISSIONS", true); //Не учитываем права доступа
	require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");
	require($_SERVER["DOCUMENT_ROOT"]."/switch/global_function.php");

	header("Expires: 0");
	header('Content-Type: application/json; charset=utf-8');	
	
	$body_post_ = json_decode(file_get_contents('php://input'), true);
	If(!$body_post_){
		$body_post_ = $_REQUEST;
	}
	
//	$body_post_['ids'] = array(0=>'34',1=>'54');
	if(!is_array($body_post_['ids']) && $body_post_['ids']){
		$temp__ = $body_post_['ids'];
		$body_post_['ids'] = array();
		$body_post_['ids'][] = $temp__;
	}

	CModule::IncludeModule('iblock');
	
	save_online();

	$sections = json_decode(file_get_contents("https://sim-sim.vip/switch/get-sections-list.php"));
	
	$array_of_params = array();
	
	foreach($sections as $k=>$elem){

		if($elem->id){
	//		echo "\n".$elem->id.'||';
			if($body_post_['ids'] && !in_array($elem->id,$body_post_['ids'])){
				continue;
			}else{
//				echo $elem->id;die();
			}
	//		echo $elem->id;
			$page_ = file_get_contents("https://sim-sim.vip/catalog/".$elem->code."/");
			preg_match_all('#\<div class\=\"smart-filter-properties\"\>(.*?)<div class=\"smart\-filter\-controls\">#is',$page_,$match);
			$filter_texts = preg_replace('#(\n)+#is',"",$match[0][1]);
			$filter_texts = preg_replace('#(\s)+#is'," ",$filter_texts);
			$filter_texts = str_replace('> <',"><",$filter_texts);
			$filter_texts = str_replace('<div class="smart-filter-property bx-filter-parameters-box',"\n<div class=\"smart-filter-property bx-filter-parameters-box",$filter_texts);
			$filter_texts = str_replace('<div class="smart-filter-properties">'."\n",'',$filter_texts);

	//		echo $filter_texts;

			preg_match_all(
				'#\<div class\=\"smart-filter-property(.*?)\"\>'.
						'\<span class\=\"bx-filter-container-modef\"\>\<\/span\>'.
						'\<div class\=\"smart-filter-property-name\"(.*?)\>(.*?)\<\/div\>'.
						'\<div class\=\"smart-filter-property-values\"(.*?)\>(.*?)\<\/div\>'.
				'\<\/div\>#is',$filter_texts,$match);

			preg_match_all('#name\=\"arrFilter_46_(.*?)\"(.*?)placeholder=\"(\d+)\"#is',$filter_texts,$match_price);
//			echo '<pre>'.print_r($match_price,1).'</pre>';die();
			
			$min_max = array();
			foreach($match_price[1] as $k=>$elem_price){
				$min_max[$elem_price] = $match_price[3][$k];
			}
			
			$array_of_params[$elem->id]['id'] = $elem->id;
			$array_of_params[$elem->id]['name'] = trim($elem->name);
			$array_of_params[$elem->id]['code'] = $elem->code;
//			print_r($match[3]);

			$k_in_ = 0;

			foreach($match[3] as $k_in=>$elem_in){
				
				$k_in_ += $k_in;
				
				$array_of_params[$elem->id]['filters'][$k_in]['name'] = trim(strip_tags($match[3][$k_in]));
				
	//			echo $match[5][$k_in];
				preg_match_all(
					'#\<div class\=\"smart-filter-property-value(.*?)\"\>'.
						'\<label(.*?)data-role\=\"label_arrFilter_(\d+)_(\d+)(.*?)\>(.*?)\<span(.*?)\>(.*?)\<\/span\>\<\/label\>'.
					'#is',$match[5][$k_in],$match2);
//				print_r($match2);die();
				
	//			$array_of_params[$elem->id][$k_in]['text'] = $match[5][$k_in];//$match[5][$k_in];
	//			$array_of_params[$elem->id][$k_in]['not_work_params'] = $match2;//$match[5][$k_in];
/*	
				foreach($match2[5] as $k_in_in=>$elem_in_in){
					$match2[5][$k_in_in] = trim($match2[5][$k_in_in]);
				}
				$array_of_params[$elem->id]['filters'][$k_in]['params'] = $match2[5];
*/				
				$arr_new_params = array();
				
				$id_prop = 0;
				
				foreach($match2[8] as $k_m=>$elem_m){
					$id_prop = $match2[3][0];
					$temp_ = trim(str_replace(array('&amp;','&quot;','amp;','quot;'),'',$elem_m));
					if(!in_array($temp_,$arr_new_params)){
						$arr_new_params[] = $temp_;
					}
				}
				
				
				$array_of_params[$elem->id]['filters'][$k_in]['id_prop'] = $id_prop;
				$array_of_params[$elem->id]['filters'][$k_in]['params'] = $arr_new_params;

				if($array_of_params[$elem->id]['filters'][$k_in]['name']=='Цена' || $array_of_params[$elem->id]['filters'][$k_in]['name']=='Базовая'){
					$array_of_params[$elem->id]['filters'][$k_in]['id_prop'] = 46;
					$array_of_params[$elem->id]['filters'][$k_in]['min'] = $min_max['MIN'];
					$array_of_params[$elem->id]['filters'][$k_in]['max'] = $min_max['MAX'];
				}
				
				
/*				
				foreach($array_of_params[$elem->id]['filters'][$k_in]['params'] as $k=>$elem){
					$array_of_params[$elem->id]['filters'][$k_in]['params'][$k] = str_replace(array('amp;','&amp;','quot;','&quot;'),'',$elem);
				}				
*/
			}
			
			$k_in_ += 1;
/*
			$array_of_params[$elem->id]['filters'][$k_in_]['name'] = 'Цена';
			$array_of_params[$elem->id]['filters'][$k_in_]['id_prop'] = 0;
			$array_of_params[$elem->id]['filters'][$k_in_]['params'] = array();
			$array_of_params[$elem->id]['filters'][$k_in_]['min'] = $min_max['MIN'];
			$array_of_params[$elem->id]['filters'][$k_in_]['max'] = $min_max['MAX'];			
*/			

			//echo '<pre>'.print_r($array_of_params,1).'</pre>';
			//die();
		}

	}

//	echo '<pre>'.print_r($sections,1).'</pre>';
	echo json_encode($array_of_params);