<?

	define("NO_KEEP_STATISTIC", true); //Не учитываем статистику
	define("NOT_CHECK_PERMISSIONS", true); //Не учитываем права доступа

	$begin_time = microtime(true);

	require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");
	require($_SERVER["DOCUMENT_ROOT"]."/switch/global_function.php");

//	header("Expires: 0");
	header('Content-Type: application/json; charset=utf-8');
	
	$body_post_ = json_decode(file_get_contents('php://input'), true);
	IF(!$body_post_){
		$body_post_ = $_REQUEST;
	}
	
	$only_postavschik = false;
	
	$only_postavschik = ($body_post_['prod']?true:false);
	$only_one = ($body_post_['ID']?$body_post_['ID']:false);
	
	$only_three = ($body_post_['only_three']?true:false);
	

	
//	$only_one = 190;
//	$only_postavschik = true;
	
	$arrFilter_top = array();

	global $USER, $arrFilter_top;
	
	require($_SERVER["DOCUMENT_ROOT"]."/switch/authorize_function.php");
	
	CModule::IncludeModule('iblock');

	$el = new CIBlockElement();
	
	$json_arr = authorize_user();
	
	if(!$json_arr['error']){
		$user_id = $USER->GetID();
	}else{
		$user_id = '';
	}

	$only_one = ($body_post_['me'] && $user_id?$user_id:$only_one);

	if($only_one){
		$filter['ID'] = $only_one;
	}else{
		if($only_postavschik){
			$filter["GROUPS_ID"] = Array(5);
		}else{
			$filter["GROUPS_ID"] = Array(6);
		}
	}

	$arParams = array('SELECT'=>array('*','UF_*'));
	$arParams = array();
	
	$rsUsers = CUser::GetList(($by="id"), ($order="desc"), $filter, $arParams); // выбираем пользователей
	$is_filtered = $rsUsers->is_filtered; // отфильтрована ли выборка ?
	$rsUsers->NavStart(10000); // разбиваем постранично по 50 записей
	
	$users_array = array();
	
	$arr_for_select = array();
	
	while($user_ = $rsUsers->getNext()){
		$arGroups = CUser::GetUserGroup($user_['ID']);
	
		$users_array[$user_['ID']]['ID'] = $user_['ID'];
		
		if(!$only_three){
			$users_array[$user_['ID']]['groups'] = $arGroups;
		}
		
		$users_array[$user_['ID']]['name'] = $user_['~NAME'];
		$users_array[$user_['ID']]['online'] = get_online($user_['ID']);
			
		if(!$only_three){			
			$users_array[$user_['ID']]['last_name'] = $user_['~LAST_NAME'];
			$users_array[$user_['ID']]['email'] = $user_['~EMAIL'];
			$users_array[$user_['ID']]['dateregister'] = $user_['~DATE_REGISTER'];
			$users_array[$user_['ID']]['phone'] = ($user_['~PERSONAL_PHONE']?$user_['~PERSONAL_PHONE']:$user_['~WORK_PHONE']);
			$users_array[$user_['ID']]['company'] = $user_['~WORK_COMPANY'];
			$users_array[$user_['ID']]['address'] = $user_['~WORK_STREET'];
			$users_array[$user_['ID']]['city'] = $user_['~WORK_CITY'];
		}
		
		if($only_postavschik || (in_array(5,$arGroups) && $only_one)){
			$arr_for_select[] = $user_['ID'];
		}
		
	}


//	echo print_r($arr_for_select,1);


	if(count($arr_for_select)>0){

		$Select = array(
			'ID',
			'PREVIEW_PICTURE',
			'DETAIL_PICTURE',
			'PROPERTY_BEST',
			'PROPERTY_POSTAVSCHIK',
			'PROPERTY_TAGS',
			'PROPERTY_GOODS',
			'PROPERTY_SALED',
			'PROPERTY_ADDRESS',
			'PROPERTY_DOP_ADDRESS',
			'PROPERTY_SUBSCRIBES',
			'PROPERTY_ISNEWGOODS'
		);
		
		$arFilter_data['PROPERTY_POSTAVSCHIK'] = $arr_for_select;


		if($body_post_['prod'] && $body_post_['best'] ==1){
			$arFilter_data['PROPERTY_BEST'] = 45;
		}
		
		
//		print_r($arr_for_select);
//		print_r($arFilter_data);
		$res = CIBlockElement::getList($arsort, $arFilter_data, false, false, $Select);

		while($row = $res->fetch()){
//			echo '1<br>';
//			echo '<pre>';
//			echo print_r($row,1);die();
//			$users_array[$row['ID']]['best'][] = $row;
//			$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['user_id'] = $row['PROPERTY_POSTAVSCHIK_VALUE'];
//			$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['PROPERTY_POSTAVSCHIK_VALUE'] =  $user_['ID'];

			if($row['PREVIEW_PICTURE']){
				$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['picture'] = Cfile::GetPath($row['PREVIEW_PICTURE']);
//				echo $users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['picture'];
			}
			
			if($row['DETAIL_PICTURE']){
				$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['picture2'] = Cfile::GetPath($row['DETAIL_PICTURE']);
			}
			
			$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['best'] = array();
			$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['osn_address'] = array();
			$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['tags'] = array();
			$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['goods'] = array();
			$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['saled'] = array();
			$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['dop_adress'] = array();
			$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['subscribes'] = array();
			$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['isnewgoods'] = array();
			$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['reviews'] = array();

	
			if($row['PROPERTY_BEST_VALUE'] && !in_array($row['PROPERTY_BEST_VALUE'],$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['best'])){
				$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['best'][] = $row['PROPERTY_BEST_VALUE'];
			}

if(!$only_three){
		
			if($row['PROPERTY_TAGS_VALUE'] && !in_array($row['PROPERTY_TAGS_VALUE'],$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['tags'])){
				$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['tags'][] = $row['PROPERTY_TAGS_VALUE'];
			}
			
}
		
			if($row['PROPERTY_GOODS_VALUE'] && !in_array($row['PROPERTY_GOODS_VALUE'],$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['goods'])){
				$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['goods'][] = $row['PROPERTY_GOODS_VALUE'];
			}else if(!in_array($row['PROPERTY_GOODS_VALUE'],$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['goods'])){
				$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['goods'][] = 0;
			}
			
			if($row['PROPERTY_SALED_VALUE'] && !in_array($row['PROPERTY_SALED_VALUE'],$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['saled'])){				
				$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['saled'][] = $row['PROPERTY_SALED_VALUE'];
			}else if(!in_array($row['PROPERTY_SALED_VALUE'],$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['saled'])){
				$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['saled'][] = 0;
			}
			
			if($row['PROPERTY_ADDRESS_VALUE'] && !in_array($row['PROPERTY_ADDRESS_VALUE'],$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['osn_address'])){
//				echo $row['PROPERTY_ADDRESS_VALUE'].'<br>';
				$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['osn_address'][] = $row['PROPERTY_ADDRESS_VALUE'];
			}
			
if(!$only_three){
	
			if($row['PROPERTY_DOP_ADDRESS_VALUE'] && !in_array($row['PROPERTY_DOP_ADDRESS_VALUE'],$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['dop_adress'])){
				$add_test = explode('||',$row['PROPERTY_DOP_ADDRESS_VALUE']);
				$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['dop_adress'][] = array('name'=>$add_test[0],'addr'=>$add_test[1]);
			}

			if($row['PROPERTY_SUBSCRIBES_VALUE'] && !in_array($row['PROPERTY_SUBSCRIBES_VALUE'],$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['subscribes'])){
				$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['subscribes'][] = $row['PROPERTY_SUBSCRIBES_VALUE'];
			}

			if($row['PROPERTY_ISNEWGOODS_VALUE'] && !in_array($row['PROPERTY_ISNEWGOODS_VALUE'],$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['isnewgoods'])){
				$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['isnewgoods'][] = $row['PROPERTY_ISNEWGOODS_VALUE'];
			}
/*			
			$users_array[$row['PROPERTY_POSTAVSCHIK_VALUE']]['reviews'] = 
			array(
				'0'=>array(
					'name'=>'Ира',
					'date'=>'2020-01-16',
					'text'=>strip_tags('Мы с этим поставщиком давно работаем хороший человек приятно торговаться с этим продавцом.'),
				),
				'1'=>array(
					'name'=>'Таня',
					'date'=>'2020-01-16',
					'text'=>strip_tags('Мы с этим поставщиком давно работаем хороший человек приятно торговаться с этим продавцом.'),
				),
			);
*/
		}

}			
		
		foreach($users_array as $k=>$elem){
//			echo $body_post_['prod'].' && '.$body_post_['best'].'==1 && '.print_r($elem['best'][0],1).'==Да) || !'.$body_post_['best']."\n";
			if(($body_post_['prod'] && $body_post_['best']==1 && $elem['best'][0]=='Да') || !$body_post_['best']){
//				echo $body_post_['prod'].'||'.$body_post_['best'].'||'.$row['PROPERTY_BEST_ENUM_ID']."\n";
					unset($users_array[$k]['best']);

			}else{
				unset($users_array[$k]);
			}
			
		}		
		
	}
	
/*	
	while($rsUsers->NavNext(true, "f_")){
		echo "[".$f_ID."] (".$f_LOGIN.") ".$f_NAME." ".$f_LAST_NAME."<br>\n";
	};
*/
//	print_r($users_array);
?>	
<?	
	$json_arr = $users_array;
//	print_r($users_array);
/*	
	foreach($two_cats['level1'] as $k=>$elem){
		$json_arr[$k]['ID'] = $elem['ID'];
		$json_arr[$k]['NAME'] = $elem['NAME'];
		if($elem['CHILDS']){
			$json_arr[$k]['CHILDS'] = array();
			foreach($elem['CHILDS'] as $k_in=>$elem_in){
				$json_arr[$k]['CHILDS'][$k_in]['ID'] = $elem_in['ID'];
				$json_arr[$k]['CHILDS'][$k_in]['NAME'] = $elem_in['NAME'];
			}
		}
	}
*/	
	echo json_encode($json_arr);

	$end_time = microtime(true);
	$all_time_sek = ($end_time - $begin_time);
	file_put_contents($_SERVER['DOCUMENT_ROOT'].'/switch/test_times/get-users-prods.txt',"----Время выполнения - ".$all_time_sek." c.----, date(".date('Y-m-d H:i:s').")-----".print_r($body_post_,1)."\n",FILE_APPEND);

?>