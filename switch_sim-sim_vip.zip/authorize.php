<?

	define("NO_KEEP_STATISTIC", true); //Не учитываем статистику
	define("NOT_CHECK_PERMISSIONS", true); //Не учитываем права доступа
	require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");

	header("Expires: 0");
	header('Content-Type: application/json; charset=utf-8');	

	CModule::IncludeModule('iblock');

	global $USER;
	
	require($_SERVER["DOCUMENT_ROOT"]."/switch/global_function.php");
	require($_SERVER["DOCUMENT_ROOT"]."/switch/authorize_function.php");
	
	$json_arr = authorize_user();
	
	echo json_encode($json_arr);

?>