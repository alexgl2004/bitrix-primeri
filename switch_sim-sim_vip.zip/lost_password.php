<?

	define("NO_KEEP_STATISTIC", true); //Не учитываем статистику
	define("NOT_CHECK_PERMISSIONS", true); //Не учитываем права доступа
	require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");
	require($_SERVER["DOCUMENT_ROOT"]."/switch/global_function.php");

	header("Expires: 0");
	header('Content-Type: application/json; charset=utf-8');	
	
	$body_post_ = json_decode(file_get_contents('php://input'), true);

	CModule::IncludeModule('iblock');

	global $USER;
	save_online();
	
	if(!$body_post_['login']){
		$body_post_['login'] = $body_post_['email'];
	}
	
	$arResult = $USER->SendPassword($body_post_['login'], $body_post_['email']);
	if($arResult["TYPE"] == "OK"){
		$json_arr['sended_email'] = true;
	}else{
		$json_arr['sended_email'] = false;
		$json_arr['message'] = str_replace('<br>','',strip_tags($arResult["MESSAGE"]));
		$json_arr['error'] = 7;
	}
	
	echo json_encode($json_arr);
	
?>