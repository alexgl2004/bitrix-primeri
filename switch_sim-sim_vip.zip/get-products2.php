<?

	define("NO_KEEP_STATISTIC", true); //Не учитываем статистику
	define("NOT_CHECK_PERMISSIONS", true); //Не учитываем права доступа

	$begin_time = microtime(true);

	$body_post_ = json_decode(file_get_contents('php://input'), true);
	If(!$body_post_){
		$body_post_ = $_REQUEST;
	}
	
	if($body_post_['page']){
		$_POST['PAGEN_1'] = $_GET['PAGEN_1'] = $_REQUEST['PAGEN_1'] = $body_post_['page'];
	}
	
	$count_prods = ($body_post_['count_prods']?$body_post_['count_prods']:20);

	
	require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");
	require($_SERVER["DOCUMENT_ROOT"]."/switch/global_function.php");
	
//	header("Expires: 0");
	header('Content-Type: application/json; charset=utf-8');
	
//	file_put_contents($_SERVER['DOCUMENT_ROOT'].'/switch/test_file.txt',"\n"."----get_products, date(".date('Y-m-d H:i:S').")-----".print_r($body_post_,1)."\n",FILE_APPEND);
	
	$arrFilter_top = array('ACTIVE'=>'Y');

	global $USER, $arrFilter_top;
	
	save_online();
	
	require($_SERVER["DOCUMENT_ROOT"]."/switch/authorize_function.php");
	
	CModule::IncludeModule('iblock');

	require($_SERVER["DOCUMENT_ROOT"] . "/tarifs.php");

	$el = new CIBlockElement();
	
	$json_arr = authorize_user();
	
	if(!$json_arr['error']){
		$user_id = $USER->GetID();
	}else{
		$user_id = '';
	}

	$user_id_IBLOCK = 32;
	$IBLOCK_ID_GOODS = 16;
	
	$get_users_prods = ($body_post_['user_products']?true:false);
	$json_user_id = ($body_post_['user_id']?$body_post_['user_id']:0);
	
//	file_put_contents($_SERVER['DOCUMENT_ROOT'].'/switch/test_file.txt',"\n".$get_users_prods."\n",FILE_APPEND);

	$property_fields = CIBlockProperty::GetList(Array("DEF"=>"DESC", "SORT"=>"ASC"), Array("IBLOCK_ID"=>16));
	
	$dop_fields = array();
	
	while($fields_ = $property_fields->GetNext()){
		if(stripos($fields_['CODE'],'DOP_')!==false){
			$dop_fields[$fields_['CODE']] = $fields_['NAME'];
		}
	}	
	
//	echo '<pre>'.print_r($dop_fields,1).'</pre>';
	
	if($user_id && $get_users_prods){
		
//		file_put_contents($_SERVER['DOCUMENT_ROOT'].'/switch/test_file.txt',"\n".$get_users_prods."\n",FILE_APPEND);
		
		$json_arr['user_products'] = true;
		
		$rsUser = CUser::GetByID($user_id);
		$arUser = $rsUser->Fetch();

//		echo '<pre>'.print_r($arr_tarifs,1).'</pre>';
//		echo $TARIF;
		$TARIF = ($arUser['UF_TARIF']?$arUser['UF_TARIF']:1);
//		echo $TARIF.'ssss';
//"∞"
		if($arr_tarifs[$TARIF]['kolvo']=='∞'){
			$tarif_prods = 'inf';
		}else{
			$tarif_prods = $arr_tarifs[$TARIF]['kolvo'];
		}
		
		if($get_users_prods){
			switch($TARIF){
				default:
				case 1:
					$tarif_prods = 30;
				break;
				case 2:
					$tarif_prods = 500;
				break;
				case 3:
					$tarif_prods = 1000;
				break;
				case 4:
					$tarif_prods = 5000;
				break;
				case 5:
					$tarif_prods = 1000000;
				break;		
			}
		}
		
		if(date('Y-m-d',strtotime($arUser['UF_DATE_MONEY'])) > date('Y-m-d')){
			$tarif_prods = $arr_tarifs[1]['kolvo'];
		}

		$json_arr['tarif_prods'] = $tarif_prods;		
		
		if( $TARIF<=1 ){
			$json_arr['error'] = 4;
//			$json_arr['user_products'] = false;
			$json_arr['message'] = 'У вас ограниченный аккаунт, только 30 товаров. Пополните счет или перейдиет на более высокий тариф, чтобы иметь больеш возможностей';
	//		echo '<b><i>Срок вашего тарифа истек, продлите действие тарифа, чтобы продолжать</i></b>';
		}

		$arrFilter_top['PROPERTY_POSTAVSCHIK'] = $user_id;
		
	}else{
//		file_put_contents($_SERVER['DOCUMENT_ROOT'].'/switch/test_file.txt',"\n".$get_users_prods."no\n",FILE_APPEND);
		$json_arr['user_products'] = false;
	}
	
	/***************filters**********************/
/*	
	$body_post_['filter'][0]['id'] = 176;
	$body_post_['filter'][0]['values'] = array(12,'04');
*/	
	
	if($body_post_['filter']){
		foreach($body_post_['filter'] as $elem){
			$arrFilter_top['PROPERTY_'.$elem['id']] = $elem['values'];
		}		
	}

	if($body_post_['search_by_name']){
		$arrFilter_top['%NAME'] = $body_post_['search_by_name'];
	}	
	
/*	
	if($body_post_['test']){
		$body_post_['filter']['price_begin'] = 500;
		$body_post_['filter']['price_end'] = 600;
	}
*/	
	
	if($body_post_['filter']){
		
		if($body_post_['filter']['price_begin']){
			$arrFilter_top[">=PROPERTY_STARTSHOP_PRICE_1"] = $body_post_['filter']['price_begin'];
		}

		if($body_post_['filter']['price_end']){
			$arrFilter_top["<=PROPERTY_STARTSHOP_PRICE_1"] = $body_post_['filter']['price_end'];
		}
		
	}
	
	
	/***************filters*********************/
	
	
	if($get_users_prods && $json_user_id){
		$arrFilter_top['PROPERTY_POSTAVSCHIK'] = $json_user_id;
	}

	if($body_post_['postavschik']){
		$arrFilter_top['PROPERTY_POSTAVSCHIK'] = $body_post_['postavschik'];
	}
	
/*	
//	$body_post_['test'] = 1;
	if($body_post_['test']){
		$body_post_['sort']['type'] = 'price';
		$body_post_['sort']['dest'] = 'desc';
	}
*/	
	
	if($body_post_['sort']){
		
		switch($body_post_['sort']['type']){
			case 'price':
				$sort1 = 'PROPERTY_STARTSHOP_PRICE_1';
			break;
			case 'new':
				$sort1 = 'DATE_CREATE';
			break;
			case 'popular':
//				$sort1 = 'propertysort_SALELEADER';
				$sort1 = 'SHOW_COUNTER';
			break;
			case 'name':
			default:
				$sort1 = 'NAME';
			break;
		}

		switch($body_post_['sort']['type2']){
			case 'price':
				$sort2 = 'PROPERTY_STARTSHOP_PRICE_1';
			break;
			case 'new':
				$sort2 = 'DATE_CREATE';
			break;
			case 'popular':
//				$sort1 = 'propertysort_SALELEADER';
				$sort2 = 'SHOW_COUNTER';
			break;
			case 'name':
			default:
				$sort2 = 'NAME';
			break;
		}		
		
		$sort1_order = strtoupper($body_post_['sort']['dest']);//asc/desc
		$sort2_order = strtoupper($body_post_['sort']['dest2']);//asc/desc

	}else{

		if($body_post_['new'] ==1){
			$sort1 = 'DATE_CREATE';
			$sort1_order = 'DESC';
			$sort2 = 'sort';
			$arrFilter_top['PROPERTY_SYSTEM_NEW'] = 56;
		}else{
			$sort1 = 'sort';
			$sort1_order = 'ASC';
			$sort2 = 'id';
		}
		
	}
	
//	$body_post_['category'] = 27;
//	$body_post_['product'] = 3071;
//	$body_post_['product'] = 3680;

//	print_r($body_post_);die();


	if($body_post_['category']){
		$arrFilter_top['SECTION_ID'] = (int)$body_post_['category'];
	}

	if($body_post_['product'] || $_REQUEST['product']){
		$arrFilter_top['ID'] = (int)($body_post_['product']?$body_post_['product']:$_REQUEST['product']);
	}
	
	if($body_post_['product']){
		$json_arr['get_one_product'] = true;
	}

	$json_arr['sort'] = $body_post_['sort'];
	$json_arr['element_count'] = (int)$count_prods;
	
	

	if(!$body_post_['product'] && !$body_post_['category'] && !$body_post_['new'] && !$body_post_['postavschik'] && !$body_post_['search_by_name'] && !$json_arr['user_products']){
		
		$json_arr['error'] = 1;
		$json_arr['message'] = 'request must have params: `category` or `product` ';
		echo json_encode($json_arr);
		
	}else{

		$json_arr['filter'] = $arrFilter_top;		
//		$json_arr['REQUEST'] = $_REQUEST;

/*
		if($body_post_['new']){
			
			unset($json_arr['filter']);
			unset($json_arr['error']);
			unset($json_arr['auth']);
			unset($json_arr['user_products']);
			
		}
*/	

//		$count_prods = ($count_prods?$count_prods:20);
		
		$APPLICATION->IncludeComponent(
			"bitrix:catalog.section", 
			"for_json2", 
			array(
				"JSON_ARR"=>$json_arr,
				"ACTION_VARIABLE" => "action",
				"BASKET_URL" => "/personal/basket/?page=order",
				"CACHE_FILTER" => "Y",
				"CACHE_GROUPS" => "Y",
				"CACHE_TIME" => "3600000",
				"CACHE_TYPE" => "A",
				"COMPONENT_TEMPLATE" => "",
				"CONVERT_CURRENCY" => "N",
				"DISPLAY_COMPARE" => "N",
//				"ELEMENT_COUNT" => $tarif_prods,
				"ELEMENT_SORT_FIELD" => $sort1,
				"ELEMENT_SORT_ORDER" => $sort1_order,
				"ELEMENT_SORT_FIELD2" => $sort2,
				"ELEMENT_SORT_ORDER2" => ($sort2_order?$sort2_order:"desc"),
				"USE_FILTER" => "Y",
				"FILTER_NAME" => "arrFilter_top",
				"HIDE_NOT_AVAILABLE" => "N",
				"IBLOCK_ID" => $IBLOCK_ID_GOODS,
				"IBLOCK_TYPE" => "catalogs",
				"LINE_ELEMENT_COUNT" => "3",
				"PRODUCT_PROPS_VARIABLE" => "prop",
				"PRODUCT_QUANTITY_VARIABLE" => "quantity",
				"PROPERTY_CODE" => array(
					0 => "POSTAVSCHIK",
					1 => "",
				),
				"SECTION_COUNT" => $count_prods,//??
				"SECTION_FIELDS" => array(
					0 => "NAME",
					1 => "",
				),
				"SECTION_ID_VARIABLE" => "SECTION_ID",
				"SECTION_SORT_FIELD" => "sort",
				"SECTION_SORT_ORDER" => "asc",
				"SECTION_USER_FIELDS" => array(
					0 => "",
					1 => "",
				),
				"SHOW_PRICE_COUNT" => "1",
				"USE_MAIN_ELEMENT_SECTION" => "Y",
				"USE_PRICE_COUNT" => "N",
				"USE_PRODUCT_QUANTITY" => "N",
				"SECTION_ID" => $body_post_["category"],
				"SECTION_CODE" => "",
				"INCLUDE_SUBSECTIONS" => "Y",
				"SHOW_ALL_WO_SECTION" => "Y",
				"PAGE_ELEMENT_COUNT" => $count_prods,
				"PROPERTY_CODE_MOBILE" => "",
				"OFFERS_LIMIT" => "5",
				"BACKGROUND_IMAGE" => "-",
				"TEMPLATE_THEME" => "blue",
				"PRODUCT_ROW_VARIANTS" => "[{'VARIANT':'2','BIG_DATA':false},{'VARIANT':'2','BIG_DATA':false},{'VARIANT':'2','BIG_DATA':false},{'VARIANT':'2','BIG_DATA':false},{'VARIANT':'2','BIG_DATA':false},{'VARIANT':'2','BIG_DATA':false}]",
				"ENLARGE_PRODUCT" => "STRICT",
				"PRODUCT_BLOCKS_ORDER" => "price,props,sku,quantityLimit,quantity,buttons",
				"SHOW_SLIDER" => "Y",
				"ADD_PICT_PROP" => "-",
				"LABEL_PROP" => "",
				"MESS_BTN_BUY" => "Купить",
				"MESS_BTN_ADD_TO_BASKET" => "В корзину",
				"MESS_BTN_SUBSCRIBE" => "Подписаться",
				"MESS_BTN_DETAIL" => "Подробнее",
				"MESS_NOT_AVAILABLE" => "Нет в наличии",
				"SHOW_FROM_SECTION" => "N",
				"SEF_MODE" => "Y",
				"SECTION_URL" => "/catalog/#SECTION_CODE#/",
				"DETAIL_URL" => "/catalog/#SECTION_CODE#/#ELEMENT_ID#/",
				"AJAX_MODE" => "N",
				"AJAX_OPTION_JUMP" => "N",
				"AJAX_OPTION_STYLE" => "Y",
				"AJAX_OPTION_HISTORY" => "N",
				"AJAX_OPTION_ADDITIONAL" => "",
				"SET_TITLE" => "Y",
				"SET_BROWSER_TITLE" => "Y",
				"BROWSER_TITLE" => "-",
				"SET_META_KEYWORDS" => "Y",
				"META_KEYWORDS" => "-",
				"SET_META_DESCRIPTION" => "Y",
				"META_DESCRIPTION" => "-",
				"SET_LAST_MODIFIED" => "N",
				"ADD_SECTIONS_CHAIN" => "N",
				"PRODUCT_ID_VARIABLE" => "id",
				"PRICE_CODE" => array(
					0 => "",
					1 => "",
				),
				"PRICE_VAT_INCLUDE" => "Y",
				"ADD_PROPERTIES_TO_BASKET" => "Y",
				"PARTIAL_PRODUCT_PROPERTIES" => "N",
				"USE_ENHANCED_ECOMMERCE" => "N",
				"PAGER_TEMPLATE" => ".default",
				"DISPLAY_TOP_PAGER" => "N",
				"DISPLAY_BOTTOM_PAGER" => "Y",
				"PAGER_TITLE" => "Товары",
				"PAGER_SHOW_ALWAYS" => "N",
				"PAGER_DESC_NUMBERING" => "N",
				"PAGER_DESC_NUMBERING_CACHE_TIME" => "360000",
				"PAGER_SHOW_ALL" => "N",
				"PAGER_BASE_LINK_ENABLE" => "Y",
				"LAZY_LOAD" => "N",
				"LOAD_ON_SCROLL" => "N",
				"SET_STATUS_404" => "N",
				"SHOW_404" => "N",
				"MESSAGE_404" => "",
				"COMPATIBLE_MODE" => "Y",
				"DISABLE_INIT_JS_IN_COMPONENT" => "N",
				"QUICK_VIEW_USE" => "N",
				"PROPERTY_MARKS_HIT" => "",
				"PROPERTY_MARKS_NEW" => "",
				"PROPERTY_MARKS_RECOMMEND" => "",
				"PROPERTY_PICTURES" => "",
				"OFFERS_PROPERTY_PICTURES" => "",
				"COLUMNS" => "3",
				"BORDERS" => "N",
				"BORDERS_STYLE" => "squared",
				"MARKS_SHOW" => "N",
				"NAME_POSITION" => "middle",
				"NAME_ALIGN" => "left",
				"PRICE_ALIGN" => "start",
				"ACTION" => "none",
				"OFFERS_USE" => "N",
				"VOTE_SHOW" => "N",
				"QUANTITY_SHOW" => "N"
			),
			false
		);
	}

	$end_time = microtime(true);

	$all_time_sek = ($end_time - $begin_time);
	
	file_put_contents($_SERVER['DOCUMENT_ROOT'].'/switch/test_times/get_products2.txt',"----Время выполнения - ".$all_time_sek." c.----, date(".date('Y-m-d H:i:s').")-----".print_r($body_post_,1)."\n",FILE_APPEND);
	
?>

	
<?/*	
	$json_arr = array();
	
	foreach($two_cats['level1'] as $k=>$elem){
		$json_arr[$k]['ID'] = $elem['ID'];
		$json_arr[$k]['NAME'] = $elem['NAME'];
		if($elem['CHILDS']){
			$json_arr[$k]['CHILDS'] = array();
			foreach($elem['CHILDS'] as $k_in=>$elem_in){
				$json_arr[$k]['CHILDS'][$k_in]['ID'] = $elem_in['ID'];
				$json_arr[$k]['CHILDS'][$k_in]['NAME'] = $elem_in['NAME'];
			}
		}
	}
	
	echo json_encode($json_arr);	
*/
?>