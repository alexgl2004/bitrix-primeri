<?

	define("NO_KEEP_STATISTIC", true); //Не учитываем статистику
	define("NOT_CHECK_PERMISSIONS", true); //Не учитываем права доступа
	define("NO_CACHE", true);
	require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");
	require($_SERVER["DOCUMENT_ROOT"]."/switch/global_function.php");

//	header("Expires: 0");
	header('Content-Type: application/json; charset=utf-8');
	
	$body_post_ = json_decode(file_get_contents('php://input'), true);
	IF(!$body_post_){
		$body_post_ = $_REQUEST;
	}
	
	global $USER;
	
	require($_SERVER["DOCUMENT_ROOT"]."/switch/authorize_function.php");
	
	CModule::IncludeModule('iblock');

	$el = new CIBlockElement();
	
	$json_arr = authorize_user();
	
	if(!$json_arr['error']){
		$user_id = $USER->GetID();
	}else{
		$user_id = '';
	}
/*	
	$body_post_ = array(
		'name'=>'Администратор',
		'last_name'=>'Администратор',
		'phone'=>'+74568713232',
		'company'=>'Рога и копыта',
		'address'=>'Тест',
		'city'=>'Екатеринбург',
		'region'=>'Свердловская область',
		'address'=>'Миномётчиков 5',
		'dop_address'=>array(
			'Whatsup||+74568713232',
			'Skype||ee.rr'
		)		
	);
*/	
	if($body_post_['dop_address']){
		foreach($body_post_['dop_address'] as $k=>$elem){
			$body_post_dop_address[$k] = array('VALUE'=>$elem);
		}
	}
	
	$body_post_['dop_address'] = $body_post_dop_address;	
	
	if((int)$user_id && $body_post_){

		if($body_post_['name']!==false){
			$arr_to_site['NAME'] = $body_post_['name'];
		}
		if($body_post_['last_name']!==false){
			$arr_to_site['LAST_NAME'] = $body_post_['last_name'];
		}
//		$arr_to_site['EMAIL'] = $body_post_['name'];
		if($body_post_['phone']!==false){
			$arr_to_site['PERSONAL_PHONE'] = $body_post_['phone'];
		}
		if($body_post_['company']!==false){
			$arr_to_site['WORK_COMPANY'] = $body_post_['company'];
		}
		if($body_post_['address']!==false){
			$arr_to_site['WORK_STREET'] = $body_post_['address'];
		}
		if($body_post_['city']!==false){
			$arr_to_site['WORK_CITY'] = $body_post_['city'];
		}
		if($body_post_['region']!==false){
			$arr_to_site['WORK_STATE'] = $body_post_['region'];
		}
		
		if($body_post_['password']){
			
			$arr_to_site['PASSWORD'] = $body_post_['password'];
			$arr_to_site['CONFIRM_PASSWORD'] = $body_post_['confirm_password'];

		}

		$user_ = new CUser;
		$user_->Update($user_id, $arr_to_site);
		$strError = $user_->LAST_ERROR;
		
		if($strError){
			$json_arr['error'] = 1;
			$json_arr['message'] = strip_tags($strError);
		}else{

	//		CIBlockElement::SetPropertyValuesEx($el_id, $iblock_id, $prop);

			$res = CIBlockElement::getList($arSort, array('IBLOCK_ID'=>32,'PROPERTY_POSTAVSCHIK' => $user_id), false, false, array('ID'));
			$row = $res->fetch();
//			$json_arr['ID'] = $user_id.'||'.$row['ID'];
			
			
			if($body_post_['address']){
				CIBlockElement::SetPropertyValuesEx($row['ID'], 32, array('ADDRESS'=>$body_post_['address']));
			}

			if($body_post_['dop_address']){
				CIBlockElement::SetPropertyValuesEx($row['ID'], 32, array('DOP_ADDRESS'=>$body_post_['dop_address']));
			}
			
			$json_arr['saved'] = true;
			
		}
		
	}
	
//	$json_arr['body_post'] = $body_post_;
	
	echo json_encode($json_arr);

?>