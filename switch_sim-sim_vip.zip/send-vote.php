<?
	define("NO_KEEP_STATISTIC", true); //Не учитываем статистику
	define("NOT_CHECK_PERMISSIONS", true); //Не учитываем права доступа
	define("NO_CACHE", true);
	require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");
	require_once($_SERVER["DOCUMENT_ROOT"].'/personal/profile/chat/inc/ajx_chat.inc.php');	
	require($_SERVER["DOCUMENT_ROOT"]."/switch/global_function.php");
	
	header("Expires: 0");
	header('Content-Type: application/json; charset=utf-8');

	global $USER, $DB;
	
	$body_post_ = json_decode(file_get_contents('php://input'), true);
	
	if(!$body_post_){
		$body_post_ = $_REQUEST;
	}

/*
	$body_post_['product_id'] = 6817;
	$body_post_['rating'] = 5;
*/	
	
	require($_SERVER["DOCUMENT_ROOT"]."/switch/authorize_function.php");
	
	CModule::IncludeModule('iblock');

	$json_arr = authorize_user();	
	
	$user_id = $USER->GetID();

	if($user_id){
		
		$product_id = $body_post_['product_id'];
		$rating = $body_post_['rating'];
		
		$arr_of_voted_products = json_decode(file_get_contents($_SERVER["DOCUMENT_ROOT"]."/chat/check_voted/vote_of_user_".$user_id),1);
//		$arr_of_voted_products = array();
		
		if(!in_array($product_id, $arr_of_voted_products)){
		
			$iterator = CIBlockElement::GetPropertyValues(16, array('ID' => $product_id), true, array('ID' => array(197, 198, 199)));
			$vote_row = $iterator->Fetch();
			
			$vote_row['197'] += 1;
			$vote_row['198'] += $rating;
			$vote_row['199'] = $vote_row['198']/$vote_row['197'];
			
			$props_ = array();
			$props_['vote_row'] = $vote_row;
			$props_['vote_count'] = $vote_row['197'];
			$props_['vote_sum'] = $vote_row['198'];
			$props_['rating'] = $vote_row['199'];
			
			CIBlockElement::SetPropertyValuesEx($product_id, 16, $props_);

			$arr_of_voted_products[] = $product_id;			
			file_put_contents($_SERVER["DOCUMENT_ROOT"]."/chat/check_voted/vote_of_user_".$user_id,json_encode($arr_of_voted_products));			
			
			$json_arr['error'] = 0;
			$json_arr['success'] = 1;
			$json_arr['props'] = $props_;
			$json_arr['vote_count'] = $vote_row['197'];
			$json_arr['vote_sum'] = $vote_row['198'];
			$json_arr['rating'] = $vote_row['199'];
			
		}else{
			
			$json_arr['success'] = 0;
			$json_arr['error'] = 101;
			$json_arr['message'] = 'Вы уже голосовали за этот товар!';
			
		}
		
	}else{
		$json_arr['success'] = 0;
		$json_arr['error'] = 100;
		$json_arr['message'] = 'Только зарегистрированные пользователи могут голосовать!';
	}
	
	echo json_encode($json_arr);	
	
	file_put_contents($_SERVER["DOCUMENT_ROOT"]."/test_send_vote.txt",print_r($body_post_,1).print_r($json_arr,1));
	
?>