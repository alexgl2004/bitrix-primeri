<?
	define("NO_KEEP_STATISTIC", true); //Не учитываем статистику
	define("NOT_CHECK_PERMISSIONS", true); //Не учитываем права доступа
	
	$begin_time = microtime(true);
	
	require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");
	require($_SERVER["DOCUMENT_ROOT"]."/switch/global_function.php");

	header("Expires: 0");
	header('Content-Type: application/json; charset=utf-8');	

	CModule::IncludeModule('iblock');

	$arFilter = array(
	  'IBLOCK_ID' => 16,
	  'CODE' => 'DOP_%',
	);

	$rsProperty = CIBlockProperty::GetList( array(), $arFilter);

	while($element = $rsProperty->Fetch()){
		$json_arr[]=array(
			'id'=>$element['ID'],
			'code'=>$element['CODE'],
			'name'=>$element['NAME']
		);
	}
	
	echo json_encode($json_arr);

	$end_time = microtime(true);
	$all_time_sek = ($end_time - $begin_time);
	file_put_contents($_SERVER['DOCUMENT_ROOT'].'/switch/test_times/get-list-characts.txt',"----Время выполнения - ".$all_time_sek." c.----, date(".date('Y-m-d H:i:s').")-----".print_r($body_post_,1)."\n",FILE_APPEND);

?>