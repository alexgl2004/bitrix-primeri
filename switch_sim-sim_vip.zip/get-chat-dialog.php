<?

	define("NO_KEEP_STATISTIC", true); //Не учитываем статистику
	define("NOT_CHECK_PERMISSIONS", true); //Не учитываем права доступа
	define("NO_CACHE", true);
	require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");
	require_once($_SERVER["DOCUMENT_ROOT"].'/personal/profile/chat/inc/ajx_chat.inc.php');	
	require($_SERVER["DOCUMENT_ROOT"]."/switch/global_function.php");

	header("Expires: 0");
	header('Content-Type: application/json; charset=utf-8');

	global $body_post_;
	
	$body_post_ = json_decode(file_get_contents('php://input'), true);
	
	if(!$body_post_){
		$body_post_ = $_REQUEST;
	}
	
	$arrFilter_top = array();

	global $USER, $arrFilter_top, $DB;
	
	require($_SERVER["DOCUMENT_ROOT"]."/switch/authorize_function.php");
	
	CModule::IncludeModule('iblock');

	$el = new CIBlockElement();
	
	$json_arr = authorize_user();
	
	if(!$json_arr['error']){
		$user_id = $USER->GetID();
	}else{
		$user_id = '';
	}

	if(CSite::InGroup( array(5))){
		$prodavec = true;
	}else{
		$prodavec = false;
	}
	
	$temp_ = $GLOBALS['AjaxChat']->getJsonMessages($body_post_);;

	$sChatMessages = $temp_['sMessages'];
	$GLOBALS['AjaxChat']->check_status(true);
/*
	require_once('inc/Services_JSON.php');
	$oJson = new Services_JSON();
	echo $oJson->encode(array('messages' => $sChatMessages));

	$json_arr[$chat_['postavschik_id']]['client_id'] = $chat_['postavschik_id'];
*/
	$json_arr['user_answer'] = $temp_['user_answer'];
	$json_arr['messages'] = $sChatMessages;
	echo json_encode($json_arr);

?>