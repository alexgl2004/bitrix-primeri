<?
	$body_ = json_decode(file_get_contents('php://input'), true);
//	$body_ = file_get_contents('php://input');
	file_put_contents('test.txt',print_r($body_,1),FILE_APPEND);
?>