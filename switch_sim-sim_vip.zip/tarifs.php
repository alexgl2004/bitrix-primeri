<?

	define("NO_KEEP_STATISTIC", true); //Не учитываем статистику
	define("NOT_CHECK_PERMISSIONS", true); //Не учитываем права доступа
	define("NO_CACHE", true);
	require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");
	require($_SERVER["DOCUMENT_ROOT"]."/switch/global_function.php");

	header("Expires: 0");
	header('Content-Type: application/json; charset=utf-8');
	require($_SERVER["DOCUMENT_ROOT"] . "/tarifs.php");
	
	global $USER;
	
	require($_SERVER["DOCUMENT_ROOT"]."/switch/authorize_function.php");
	
	$json_arr = authorize_user();

	$user_id = $USER->getID();

	$rsUser = CUser::GetByID($user_id);
	$arUser = $rsUser->Fetch();
	$tarif = $arUser["UF_TARIF"];

	foreach($arr_tarifs as $k=>$elem){
		
		$json_arr[$k]['name'] = $elem['name'];
		$json_arr[$k]['tarif_color'] = $elem['class_color'];
		$json_arr[$k]['price'] = ($elem['price']?$elem['price']:'без оплаты');
		$json_arr[$k]['countProds'] = $elem['kolvo'];
		if($tarif==$k){
			$json_arr[$k]['user_tarif'] = true;
		}
		
	}
	
	echo json_encode($json_arr);

?>