<?

	define("NO_KEEP_STATISTIC", true); //Не учитываем статистику
	define("NOT_CHECK_PERMISSIONS", true); //Не учитываем права доступа
	define("NO_CACHE", true);
	require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");
	require_once($_SERVER["DOCUMENT_ROOT"].'/personal/profile/chat/inc/ajx_chat.inc.php');	
	require($_SERVER["DOCUMENT_ROOT"]."/switch/global_function.php");
	
	error_reporting(0);

	header('Accept: application/json');
	
	header("Expires: 0");
	header('Content-Type: application/json; charset=utf-8');
	
	$body_post_ = json_decode(file_get_contents('php://input'), true);
	
	$arrFilter_top = array();

	global $USER, $arrFilter_top, $DB;
	
	require($_SERVER["DOCUMENT_ROOT"]."/switch/authorize_function.php");
	
	CModule::IncludeModule('iblock');

	$el = new CIBlockElement();
	
	$json_arr = authorize_user();
	
	if(!$json_arr['error']){
		$user_id = $USER->GetID();
	}else{
		$user_id = '';
	}

	if(CSite::InGroup( array(5))){
		$prodavec = true;
	}else{
		$prodavec = false;
	}	
	
	$temp_user = $GLOBALS['AjaxChat']->check_user_id();
	$user_id = $temp_user['user_id'];
	$logined = $temp_user['logined'];
//	print_r($GLOBALS['AjaxChat']);
	
	if($prodavec){
		$dbaMessages = $DB->Query("SELECT `chat_id`,`client_id`,`member_name`, MAX(`when`) as `cdate` FROM `s_ajax_chat_messages` WHERE `postavschik_id`='".$user_id."' AND status!='D'  GROUP BY chat_id ORDER BY `cdate` DESC");	
	}else{
		$dbaMessages = $DB->Query("SELECT `chat_id`,`postavschik_id`,`member_name`, MAX(`when`) as `cdate` FROM `s_ajax_chat_messages` WHERE `client_id`='".$user_id."' AND status!='D'  GROUP BY chat_id ORDER BY `cdate` DESC");
	}
	
	if($dbaMessages->result->num_rows){
		
		$arr_user_messages = json_decode(file_get_contents('/home/bitrix/www/chat/check_json/check_file_user_'.$user_id.'.txt'),true);

		while($chat_ = $dbaMessages->Fetch()){
			
			if($prodavec){
				
				$rsUser = $USER->GetByID((int)$chat_['client_id']);
				
				if(!$rsUser->result->num_rows){
					
					$rsUser = $DB->Query("SELECT `name` FROM `s_members` WHERE `id`='".$chat_['client_id']."' LIMIT 1");
					$client_all = $rsUser->Fetch();
					$client_name = $client_all['name'];
					
				}else{
					
					$client_all = $rsUser->Fetch();
					$client_name = $client_all['NAME'].($client_all['LAST_NAME']?' '.$client_all['LAST_NAME']:'');
					
				}
				
				if(!trim($client_name)){
					$client_name = 'Имя не указано';
				}
				
				$json_arr['messages'][$chat_['client_id']]['client_id'] = $chat_['client_id'];
				$json_arr['messages'][$chat_['client_id']]['count_new'] = ($arr_user_messages[$chat_['client_id']]?$arr_user_messages[$chat_['client_id']]:0);
				$json_arr['messages'][$chat_['client_id']]['date'] = date('Y-m-d H:i:s',$chat_['cdate']);
				$json_arr['messages'][$chat_['client_id']]['name'] = $client_name;
				$json_arr['messages'][$chat_['client_id']]['online'] = get_online($chat_['client_id']);
				
			}else{

				$rsUser = $USER->GetByID((int)$chat_['postavschik_id']);
				$client_all = $rsUser->Fetch();
//				echo '<pre>'.print_r($client_all,1).'</pre>';
				$client_name = $client_all['WORK_COMPANY'];

				$json_arr['messages'][$chat_['postavschik_id']]['client_id'] = $chat_['postavschik_id'];
				$json_arr['messages'][$chat_['postavschik_id']]['count_new'] = ($arr_user_messages[$chat_['postavschik_id']]?$arr_user_messages[$chat_['postavschik_id']]:0);
				$json_arr['messages'][$chat_['postavschik_id']]['date'] = date('Y-m-d H:i:s',$chat_['cdate']);
				$json_arr['messages'][$chat_['postavschik_id']]['name'] = $client_name;
				$json_arr['messages'][$chat_['postavschik_id']]['online'] = get_online($chat_['client_id']);

			}
//			echo '<pre>'.print_r($chat_,1).'</pre>';
			
		}
	
	}
	
//	echo  json_encode(array('a'=>'b'));
	
	echo json_encode($json_arr);//, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE);
//	file_put_contents($_SERVER['DOCUMENT_ROOT'].'/switch/test_file_chat_get.txt',"\n".json_encode($json_arr)."\n");
//	file_put_contents($_SERVER['DOCUMENT_ROOT'].'/switch/test_file_chat_2.txt',json_encode($json_arr));

//	exit;

?>