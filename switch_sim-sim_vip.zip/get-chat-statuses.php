<?

	define("NO_KEEP_STATISTIC", true); //Не учитываем статистику
	define("NOT_CHECK_PERMISSIONS", true); //Не учитываем права доступа
	define("NO_CACHE", true);
	require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");
	require_once($_SERVER["DOCUMENT_ROOT"].'/personal/profile/chat/inc/ajx_chat.inc.php');	
	require($_SERVER["DOCUMENT_ROOT"]."/switch/global_function.php");

	header("Expires: 0");
	header('Content-Type: application/json; charset=utf-8');

	global $body_post_;
	
	$body_post_ = json_decode(file_get_contents('php://input'), true);
	
	if(!$body_post_){
		$body_post_ = $_REQUEST;
	}
	
	$arrFilter_top = array();

	global $USER, $arrFilter_top, $DB;
	
	require($_SERVER["DOCUMENT_ROOT"]."/switch/authorize_function.php");
	
	CModule::IncludeModule('iblock');

	$el = new CIBlockElement();
	
	$json_arr = authorize_user();
	
	if(!$json_arr['error']){
		$user_id = $USER->GetID();
	}else{
		$user_id = '';
	}

	if( $_REQUEST['client_id'] ){
		$prodavec = true;
	}else{
		$prodavec = false;
	}
	
	$json_arr = array();

	$file_json = json_decode(file_get_contents('https://sim-sim.vip/chat/check_json/check_file_user_'.$user_id.'.txt'),1);

	if($file_json){	
		foreach($file_json as $k=>$elem){
			$json_arr[$k]['count_messages'] = $elem;
			$json_arr[$k]['online'] = get_online($user_id);
			$file_is_new_p = file_get_contents('https://sim-sim.vip/chat/check_json/check_file_'.$user_id.'_'.$k.'_postav.txt');
			if((string)$file_is_new_p=='1' || (string)$file_is_new_p=='0'){
				$json_arr[$k]['is_new'] = (bool)$file_is_new_p;
			}else{
				$file_is_new_c = file_get_contents('https://sim-sim.vip/chat/check_json/check_file_'.$user_id.'_'.$k.'_client.txt');
				if((string)$file_is_new_p=='1'){
					$json_arr[$k]['is_new'] = (bool)$file_is_new_p;
				}else{
					unset($json_arr[$k]);
				}
			}

		}
		$json_arr['chats'] = count($json_arr);
	}else{
		$json_arr['chats'] = 0;
	}
	
	echo json_encode($json_arr);

?>