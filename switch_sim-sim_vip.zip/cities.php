<?
	define("NO_KEEP_STATISTIC", true); //Не учитываем статистику
	define("NOT_CHECK_PERMISSIONS", true); //Не учитываем права доступа
	require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");
	require($_SERVER["DOCUMENT_ROOT"]."/switch/global_function.php");

	header("Expires: 0");
	header('Content-Type: application/json; charset=utf-8');	

	CModule::IncludeModule('iblock');

	global $DB;

	$file_name = $_SERVER['DOCUMENT_ROOT'].'/jsons/country_cities/cities.txt';
	if(file_exists($file_name)){
		$cities = unserialize(file_get_contents($file_name));
	}else{
		$rscity = $DB->Query("SELECT * FROM `s_cities` ORDER by `country`, `city` ASC");
		$cities = array();
		while($city = $rscity->Fetch()){
			$cities[$city['country']][] = $city['city'];
		}
		file_put_contents(serialize($file_name));
	}
	
	$json_arr = array();
	$k_ = 0;
	
	foreach($cities as $k => $elem){
		$json_arr[$k_]['country'] = $k;
		$json_arr[$k_]['city'] = $elem;
		$k_ += 1;
	}
	
	echo json_encode($json_arr);

?>